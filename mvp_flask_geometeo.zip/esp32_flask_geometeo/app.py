from flask import Flask, request, render_template
from datetime import datetime

app = Flask(__name__)

last_encrypted = "Ожидание LoRa..."
last_plain = "Ожидание Wi-Fi..."
last_timestamp = "—"

@app.route('/')
def index():
    return render_template("index.html",
                           encrypted=last_encrypted,
                           plain=last_plain,
                           parsed=parse_plain(last_plain),
                           timestamp=last_timestamp)

@app.route('/encrypted', methods=['POST'])
def receive_encrypted():
    global last_encrypted, last_timestamp
    last_encrypted = request.data.decode()
    last_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return "Encrypted received", 200

@app.route('/plain', methods=['POST'])
def receive_plain():
    global last_plain, last_timestamp
    last_plain = request.data.decode()
    last_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return "Plain received", 200

def parse_plain(data):
    if not data.startswith("ID:"): return {}
    parts = data.split(",")
    parsed = {}
    for item in parts:
        if ":" in item:
            key, val = item.split(":", 1)
            parsed[key.strip()] = val.strip()
    return parsed

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
